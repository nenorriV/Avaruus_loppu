﻿using System.Numerics;
using Raylib_CsLo;

namespace Invaders_demo
{
    internal class Player
    {
        public TransformComponent transform { get; private set; }
        public CollisionComponent collision;
        SpriteRendererComponent spriteRenderer;

        double shootInterval = 0.3;
        double lastShootTime;

        public bool active;

        public Player(Vector2 startPos, Vector2 direction, float speed, int size, Texture image)
        {
            transform = new TransformComponent(startPos, direction, speed);
            collision = new CollisionComponent(new Vector2(size, size));
            spriteRenderer = new SpriteRendererComponent(image, Raylib.SKYBLUE, transform, collision);

            lastShootTime = -shootInterval;
            active = true;
        }


        /// <summary>
        /// Updates player position, listens to keyboard 
        /// </summary>
        /// <returns>True when player wants to shoot, false normally</returns>
        public bool Update()
        {
            float deltaTime = Raylib.GetFrameTime();

            Vector2 mousPos = Raylib.GetMousePosition();
            Vector2 center = transform.position + collision.size /2;

            if (Raylib.IsKeyDown(KeyboardKey.KEY_A) || center.X > mousPos.X)
            {
                transform.position.X -= transform.speed * deltaTime;
            }
            else if (Raylib.IsKeyDown(KeyboardKey.KEY_D)|| center.X < mousPos.X)
            {
                transform.position.X += transform.speed * deltaTime;
            }

            bool shoot = false;
            if (Raylib.IsKeyDown(KeyboardKey.KEY_SPACE)||
            Raylib.IsMouseButtonDown(MouseButton.MOUSE_BUTTON_LEFT))
            {
   
                double timeNow = Raylib.GetTime();
                double timeSinceLastShot = timeNow - lastShootTime;
                if (timeSinceLastShot >= shootInterval)
                {
                    Console.WriteLine("Player shoots!");
                    lastShootTime = timeNow;
                    shoot = true;
                }
            }
            return shoot;
        }

        public void Draw()
        {
            spriteRenderer.Draw();
        }

    }
}