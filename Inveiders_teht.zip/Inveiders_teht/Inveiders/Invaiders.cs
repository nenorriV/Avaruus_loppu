﻿using Inveiders;
using Newtonsoft.Json;
using Raylib_CsLo;
using System;
using System.Numerics;
using System.Reflection.Metadata.Ecma335;

namespace Invaders_demo
{
    internal class Invaiders
    {

        enum GameState
        {
            MainMenu,
            Start,
            Play,
            ScoreScreen,
            SettingsMenu,
            Pause,
            DevMenu
        }
        GameState state;

        int window_width = 640;
        int window_height = 720;

        int activeIndex = 0;

        const float playerSpeed = 220;
        const int playerSize = 40;

        Player player;
        List<Bullet> bullets;
        List<Enemy> enemies;

        List<Vector2> startScreenStars;

        float playerBulletSpeed;

        int bulletSize;

        bool dev_player_invulnerable = false;

        double enemyShootInterval;
        double lastEnemyShootTime;
        float enemyBulletSpeed;
        float enemySpeed;
        float enemySpeedDown;
        float enemyMaxYLine;

        Texture playerImage;
        Sound shootSound;
        List<Texture> enemyImages;
        Texture bulletImage;

        int scoreCounter = 0;

        int enemyKilled = 0;

        double timeLastCheck = 0;
        double gamerPlaySeconds = 0;

        public void Run()
        {
            Init();
            GameLoop();
        }

        void Init()
        {
            Raylib.InitWindow(window_width, window_height, "Space Invaders");
            Raylib.SetTargetFPS(30);

            Raylib.SetExitKey(0);

            state = GameState.Start;

            playerImage = Raylib.LoadTexture("image/pelaaja.png");
            enemyImages = new List<Texture>(4);
            enemyImages.Add(Raylib.LoadTexture("data/images/enemyBlack1.png"));
            enemyImages.Add(Raylib.LoadTexture("data/images/enemyBlue2.png"));
            enemyImages.Add(Raylib.LoadTexture("data/images/enemyGreen3.png"));
            enemyImages.Add(Raylib.LoadTexture("data/images/enemyRed4.png"));

            bulletImage = Raylib.LoadTexture("data/images/laserGreen14.png");

            Raylib.InitAudioDevice();

            shootSound = Raylib.LoadSound("image/shoot.wav");

            Random random = new Random();

            startScreenStars = new List<Vector2>(20);
            for (int i = 0; i < startScreenStars.Capacity; i++)
            {
                startScreenStars.Add(new Vector2(random.Next(0, window_width), random.Next(-window_height, -1)));
            }
        }

        /// <summary>
        /// Resets everything back to starting position
        /// </summary>
        void ResetGame()
        {
            enemyKilled = 0;
            gamerPlaySeconds = 0;
            Vector2 playerStart = new Vector2(window_width / 2, window_height - playerSize * 2);

            player = new Player(playerStart, new Vector2(0, 0), playerSpeed, playerSize, playerImage);
            playerBulletSpeed = 320;

            bullets = new List<Bullet>();
            bulletSize = 16;

            enemies = new List<Enemy>();

            enemyShootInterval = 1.0f;
            lastEnemyShootTime = 5.0f;
            enemyBulletSpeed = 60;
            enemySpeed = playerSpeed;
            enemySpeedDown = 10;
            enemyMaxYLine = window_height - playerSize * 4;

            
            int rows = 4;
            int columns = 4;
            int startX = 0;
            int startY = playerSize;
            int currentX = startX;
            int currentY = startY;
            int enemyBetween = playerSize;

            int enemySize = playerSize;

            int maxScore = 40;
            int minScore = 10;
            int currentScore = maxScore;

            for (int row = 0; row < rows; row++)
            {
                currentX = startX;

                currentScore = maxScore - row * 10;
                if (currentScore < minScore)
                {
                    currentScore = minScore;
                }
                for (int col = 0; col < columns; col++)
                {
                    Vector2 enemyStart = new Vector2(currentX, currentY);
                    int enemyScore = currentScore;

                    Enemy enemy = new Enemy(enemyStart, new Vector2(1, 0), enemySpeed, enemySize, enemyImages[row], enemyScore);

                    enemies.Add(enemy);

                    currentX += enemySize + enemyBetween;
                }
                currentY += enemySize + enemyBetween;
            }

        }

        void GameLoop()
        {
            while (Raylib.WindowShouldClose() == false)
            {
                switch (state)
                {
                    case GameState.Start:
                        // default property id - 0, TEXT_SIZE property id - 16        
                        RayGui.GuiSetStyle(0, 16, 40);
                        StartUpdate();
                        Raylib.BeginDrawing();
                        Raylib.ClearBackground(Raylib.BLACK);
                        StartDraw();
                        Raylib.EndDrawing();

                        break;
                    case GameState.Play:
                        Update();
                        Raylib.BeginDrawing();
                        Raylib.ClearBackground(Raylib.DARKBLUE);
                        Draw();
                        Raylib.EndDrawing();
                        break;

                    case GameState.ScoreScreen:
                        ScoreUpdate();
                        Raylib.BeginDrawing();
                        Raylib.ClearBackground(Raylib.DARKGRAY);
                        ScoreDraw();
                        Raylib.EndDrawing();
                        break;

                    case GameState.SettingsMenu:
                        Raylib.BeginDrawing();
                        Raylib.ClearBackground(Raylib.DARKGRAY);
                        // default== 0,  TEXT_SIZE == 16        
                        SettingsMenuDraw();
                        Raylib.EndDrawing();
                        break;

                    case GameState.Pause:
                        Raylib.BeginDrawing();
                        Raylib.ClearBackground(Raylib.DARKGRAY);
                        // default property id - 0, TEXT_SIZE property id - 16        
                        RayGui.GuiSetStyle(0, 16, 40);
                        PauseMenuDraw();
                        Raylib.EndDrawing();
                        break;

                    case GameState.DevMenu:
                        // default property id - 0, TEXT_SIZE property id - 16        
                        RayGui.GuiSetStyle(0, 16, 40);
                        Raylib.BeginDrawing();
                        Raylib.ClearBackground(Raylib.DARKGRAY);
                        DevMenuDraw();
                        Raylib.EndDrawing();
                        break;


                }
            }
        }
        void Update()
        {
            if (Raylib.IsKeyReleased(KeyboardKey.KEY_P) || Raylib.IsKeyReleased(KeyboardKey.KEY_ESCAPE))
            {
                state = GameState.Pause;
            }

            if (Raylib.IsKeyReleased(KeyboardKey.KEY_I))
            {
                state = GameState.DevMenu;
            }

            // Get elapsed time in seconds since InitWindow()
            double timeNow = Raylib.GetTime();

            gamerPlaySeconds += timeNow - timeLastCheck;

            timeLastCheck = timeNow;

            UpdatePlayer();
            UpdateEnemies();
            UpdateBullets();
            CheckCollisions();
        }
        void UpdatePlayer()
        {
            bool playerShoots = player.Update();
            KeepInsideArea(player.transform, player.collision,
                0, 0, window_width, window_height);
            if (playerShoots)
            {
                float x = player.transform.position.X + player.collision.size.X / 2 - bulletSize / 2;
                float y = player.transform.position.Y - bulletSize;
                Vector2 bPos = new Vector2(x, y);

                CreateBullet(bPos,
                    new Vector2(0, -1),
                    playerBulletSpeed, bulletSize);

                Console.WriteLine($"Bullet count: {bullets.Count}");
            }
        }
        void UpdateEnemies()
        {
            bool changeFormationDirection = false;
            bool canGoDown = true;
            foreach (Enemy enemy in enemies)
            {
                if (enemy.active)
                {
                    enemy.Update();

                    bool enemyIn = IsInsideArea(enemy.transform, enemy.collision, 0, 0, window_width, window_height);

                    if (enemyIn == false)
                    {
                        changeFormationDirection = true;
                    }
                    if (enemy.transform.position.Y > enemyMaxYLine)
                    {
                        canGoDown = false;
                    }
                }
            }

            if (changeFormationDirection)
            {
                foreach (Enemy enemy in enemies)
                {
                    enemy.transform.direction.X *= -1.0f;
                    if (canGoDown)
                    {
                        enemy.transform.position.Y += enemySpeedDown;
                    }
                }
            }

            double timeNow = Raylib.GetTime();
            if (timeNow - lastEnemyShootTime >= enemyShootInterval)
            {
                Enemy shooter = FindBestEnemyShooter();
                if (shooter != null)
                {
                    float x = shooter.transform.position.X + shooter.collision.size.X / 2 - bulletSize / 2;
                    float y = shooter.transform.position.Y + shooter.collision.size.Y;
                    Vector2 bPos = new Vector2(x, y);

                    CreateBullet(bPos, new Vector2(0, 1), enemyBulletSpeed, (int)bulletSize);

                    lastEnemyShootTime = timeNow;
                }
            }
        }

        /// <summary>
        /// Finds the enemy who is in the best position to shoot at the player
        /// </summary>
        /// <returns>The enemy who should shoot or null if no enemy is in good position</returns>
        Enemy FindBestEnemyShooter()
        {
            Enemy best = null;
            float bestY = 0.0f;
            float bestXDifference = window_width;

            for (int i = enemies.Count - 1; i >= 0; i--)
            {
                Enemy candidate = enemies[i];
                if (candidate.active)
                {
                    if (candidate.transform.position.Y >= bestY || best == null)
                    {
                        bestY = candidate.transform.position.Y;

                        float xDifference = Math.Abs(player.transform.position.X - candidate.transform.position.X);
                        if (xDifference < bestXDifference && xDifference < bulletSize)
                        {
                            bestXDifference = xDifference;
                            best = candidate;
                        }
                    }
                }
            }

            return best;
        }


        void UpdateBullets()
        {
            foreach (Bullet bullet in bullets)
            {
                if (bullet.active)
                {
                    bullet.Update();

                    bool isOutside = KeepInsideArea(bullet.transform, bullet.collision, 0, 0, window_width, window_height);

                    if (isOutside)
                    {
                        bullet.active = false;
                    }
                }
            }
        }

        /// <summary>
        /// Test each enemy against each bullet for collision.
        /// On collision set both enemy and bullet as inactive.
        /// </summary>
        void CheckCollisions()
        {
            Rectangle playerRect = getRectangle(player.transform, player.collision);
            foreach (Enemy enemy in enemies)
            {
                if (enemy.active == false)
                {
                    continue;
                }
                Rectangle enemyRec = getRectangle(enemy.transform, enemy.collision);

                foreach (Bullet bullet in bullets)
                {
                    if (bullet.active == false)
                    {
                        continue;
                    }
                    Rectangle bulletRec = getRectangle(bullet.transform, bullet.collision);

                    if (bullet.transform.direction.Y < 0)
                    {
                        if (Raylib.CheckCollisionRecs(bulletRec, enemyRec))
                        {
                            Console.WriteLine($"Enemy Hit! Got {enemy.scoreValue} points!");

                            Raylib.PlaySound(shootSound);

                            enemyKilled += 1;

                            scoreCounter += enemy.scoreValue;
                            enemy.active = false;
                            bullet.active = false;

                            int enemiesLeft = CountAliveEnemies();
                            if (enemiesLeft == 0)
                            {
                                state = GameState.ScoreScreen;
                            }
                            break;
                        }
                    }
                    else
                    {
                        if (!dev_player_invulnerable && Raylib.CheckCollisionRecs(bulletRec, playerRect))
                        {
                            state = GameState.ScoreScreen;
                            player.active = false;
                        }
                    }
                }
            }
        }
        /// <summary>
        /// Either reactivates existing bullet or creates a new one
        /// </summary>
        /// <param name="pos">Starting position</param>
        /// <param name="dir">Starting direction</param>
        /// <param name="speed">Speed in pixels</param>
        /// <param name="size">Size in pixels</param>
        void CreateBullet(Vector2 pos, Vector2 dir, float speed, int size)
        {
            bool found = false;
            foreach (Bullet bullet in bullets)
            {
                if (bullet.active == false)
                {
                    bullet.Reset(pos, dir, speed, size);
                    found = true;
                    break;
                }
            }
            if (found == false)
            {
                bullets.Add(new Bullet(pos, dir, speed, size, bulletImage, Raylib.RED));
            }
        }

        Rectangle getRectangle(TransformComponent t, CollisionComponent c)
        {
            Rectangle r = new Rectangle(t.position.X,
                t.position.Y, c.size.X, c.size.Y);
            return r;
        }

        /// <summary>
        /// Keeps the given transform inside the given area bounds
        /// </summary>
        /// <param name="transform"></param>
        /// <param name="collision"></param>
        /// <param name="left"></param>
        /// <param name="top"></param>
        /// <param name="right"></param>
        /// <param name="bottom"></param>
        /// <returns>True if went outside given area</returns>
        bool KeepInsideArea(TransformComponent transform, CollisionComponent collision,
            int left, int top, int right, int bottom)
        {
            float newX = Math.Clamp(transform.position.X, left, right - collision.size.X);
            float newY = Math.Clamp(transform.position.Y, top, bottom - collision.size.Y);

            bool xChange = newX != transform.position.X;
            bool yChange = newY != transform.position.Y;

            transform.position.X = newX;
            transform.position.Y = newY;

            return xChange || yChange;
        }

        bool IsInsideArea(TransformComponent transform, CollisionComponent collision,
            int left, int top, int right, int bottom)
        {
            float x = transform.position.X;
            float r = x + collision.size.X;

            float y = transform.position.Y;
            float b = y + collision.size.Y;

            if (x < left || y < top || r > right || b > bottom)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        void Draw()
        {
            player.Draw();

            foreach (Bullet bullet in bullets)
            {
                if (bullet.active)
                {
                    bullet.Draw();
                }
            }

            foreach (Enemy enemy in enemies)
            {
                if (enemy.active)
                {
                    enemy.Draw();
                }
            }

            Raylib.DrawText($"Score: {scoreCounter}", 10, 10, 20, Raylib.WHITE);
        }

        int CountAliveEnemies()
        {
            int alive = 0;
            foreach (Enemy enemy in enemies)
            {
                if (enemy.active)
                {
                    alive++;
                }
            }
            return alive;
        }

        void DrawTextCentered(string text, int y, int fontSize, Color color)
        {
            int sw = Raylib.MeasureText(text, fontSize);

            Raylib.DrawText(text, window_width / 2 - sw / 2
                , y, fontSize, color);
        }


        void StartUpdate()
        {

            for (int i = 0; i < startScreenStars.Count; i++)
            {
                Vector2 s = startScreenStars[i];
                s.Y = s.Y + 40 * Raylib.GetFrameTime();
                s.Y = s.Y % window_height;
                startScreenStars[i] = new Vector2(s.X, s.Y);
            }
        }

        void StartDraw()
        {

            Raylib.DrawCircleGradient(window_width / 2, window_height / 2 - 100, window_height * 3.0f, Raylib.BLACK, Raylib.BLUE);

            for (int i = 0; i < startScreenStars.Count; i++)
            {
                Raylib.DrawCircleGradient((int)startScreenStars[i].X, (int)startScreenStars[i].Y, 4.0f, Raylib.WHITE, Raylib.BLACK);
            }

            Color[] colors = { Raylib.LIGHTGRAY, Raylib.GRAY, Raylib.DARKGRAY, Raylib.GREEN };
            string gameName1 = "SPACE";
            string gameName2 = "INVADERS";
            int fontSize = 60;
            for (int i = 0; i < colors.Length; i++)
            {
                double change = Math.Sin(Raylib.GetTime() + i) * 4.0;
                double y = 120 + change * 14.0;

                DrawTextCentered(gameName1, (int)(y), fontSize, colors[i]);
                DrawTextCentered(gameName2, (int)(y + 60), fontSize, colors[i]);
            }

            MenuCreator menuCreator = new MenuCreator();

            menuCreator.startMenu(500, 350, 260, 90);

            if (menuCreator.buttonCentered("Start game", 80, window_width))
            {
                ResetGame();
                state = GameState.Play;
            }

            menuCreator.addSplit(5);

            if (menuCreator.buttonCentered("Options", 80, window_width))
            {
                state = GameState.SettingsMenu;
            }

            menuCreator.addSplit(5);

            if (menuCreator.buttonCentered("Quit", 80, window_width))
            {
                Raylib.CloseWindow();
            }
        }

        void DevMenuDraw()
        {
            if (Raylib.IsKeyReleased(KeyboardKey.KEY_I))
            {
                state = GameState.Play;
            }

            MenuCreator menuCreator = new MenuCreator();

            menuCreator.startMenu(10, 80, 260, 90);
            string dev_menu_text = "DEV MENU";

            int fontSize = 60;

            string invulnerable_enable_disable_text = "make player invulnerable";

            if (dev_player_invulnerable)
            {
                invulnerable_enable_disable_text = "make player vulnerable";
            }

            menuCreator.textCentered(dev_menu_text, fontSize, window_width, Raylib.YELLOW);

            if (menuCreator.buttonCentered(invulnerable_enable_disable_text, fontSize, window_width))
            {
                dev_player_invulnerable = !dev_player_invulnerable;
            }

            menuCreator.addSplit(8);

            if (menuCreator.buttonCentered("kill all", fontSize, window_width))
            {
                foreach (Enemy enemy in enemies)
                {
                    enemy.active = false;
                }
            }

            menuCreator.addSplit(8);

            if (menuCreator.buttonCentered("continue game", fontSize, window_width))
            {
                ResetGame();
                state = GameState.Play;
            }

        }

        void PauseMenuDraw()
        {
            MenuCreator menuCreator = new MenuCreator();

            menuCreator.startMenu(10, 80, 260, 90);
            string pause_text = "PAUSE";

            string gamerplayed_time = $"gamer play {((int)gamerPlaySeconds)} sec";

            string enemies_killed_string = $"enemies killed {enemyKilled}";

            int fontSize = 60;

            menuCreator.textCentered(pause_text, fontSize, window_width, Raylib.YELLOW);
            menuCreator.textCentered(gamerplayed_time, fontSize, window_width, Raylib.YELLOW);
            menuCreator.textCentered(enemies_killed_string, fontSize, window_width, Raylib.YELLOW);
            if (menuCreator.buttonCentered("restart game", fontSize, window_width))
            {
                ResetGame();
                state = GameState.Play;
            }

            menuCreator.addSplit(10);

            if (menuCreator.buttonCentered("continue game", fontSize, window_width))
            {
                state = GameState.Play;
            }

            menuCreator.addSplit(10);

            if (menuCreator.buttonCentered("main menu", fontSize, window_width))
            {
                state = GameState.Start;
            }

            menuCreator.addSplit(10);

#if DEBUG
            if (menuCreator.buttonCentered("DEV menu", fontSize, window_width))
            {
                state = GameState.DevMenu;
            }
#endif
        }

        void ScoreUpdate()
        {
            if (Raylib.IsKeyPressed(KeyboardKey.KEY_ENTER))
            {
                ResetGame();
                state = GameState.Play;
            }
        }

        void SettingsMenuDraw()
        {
            MenuCreator menuCreator = new MenuCreator();

            menuCreator.startMenu(10, 80, 400, 90);

            string pause_text = "SETTINGS";

            int fontSize = 60;

            menuCreator.textCentered(pause_text, fontSize, window_width, Raylib.YELLOW);

            RayGui.GuiSetStyle(0, 16, 30);

            bool isActive = false;

            //                           0            1                2            3             4
            string[] menuOptions = { "Volume Off", "Volume 25%", "Volume 50%", "Volume 75%", "Volume 100%" };

            if (menuCreator.сomboBox(menuOptions, ref activeIndex, isActive))
            {
                if (activeIndex == 0)
                {
                    Raylib.SetMasterVolume(0.0f);
                }
                else if (activeIndex == 1)
                {
                    // Volume 25%
                    Raylib.SetMasterVolume(0.25f);
                }
                else if (activeIndex == 2)
                {
                    Raylib.SetMasterVolume(0.50f);
                }
                else if (activeIndex == 3)
                {
                    Raylib.SetMasterVolume(0.75f);
                }
                else if (activeIndex == 4)
                {
                    Raylib.SetMasterVolume(1.00f);
                }
            }

            menuCreator.addSplit(10);

            if (menuCreator.buttonCentered("main menu", fontSize, window_width))
            {
                state = GameState.Start;
            }


        }

        void ScoreDraw()
        {

            string scoreText = $"Final score {scoreCounter}";


            string instructionText = "Game over. Press Enter to play again";
            if (player.active == true)
            {
                instructionText = "You Won! Press Enter to play again";
            }

            int fontSize = 20;
            int sw = Raylib.MeasureText(scoreText, fontSize);
            int iw = Raylib.MeasureText(instructionText, fontSize);

            Raylib.DrawText(scoreText, window_width / 2 - sw / 2
                , window_height / 2 - 60, fontSize, Raylib.WHITE);

            Raylib.DrawText(instructionText, window_width / 2 - iw / 2,
                window_height / 2, fontSize, Raylib.WHITE);
        }
    }
}