﻿namespace Invaders_demo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Invaiders game = new Invaiders();
            game.Run();
        }
    }
}