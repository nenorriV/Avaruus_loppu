﻿using Raylib_CsLo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inveiders
{
    class MenuCreator
    {
        private int x;
        private int y;
        private int menuWidth;
        private int rowHeight;

        public void startMenu(int startX, int startY, int menuWidth, int rowHeight)
        {
            this.x = startX;
            this.y = startY;
            this.menuWidth = menuWidth;
            this.rowHeight = rowHeight;
        }

        public bool button(string text)
        {
            Rectangle buttonRect = new Rectangle(x, y, menuWidth, rowHeight);
            bool isClicked = RayGui.GuiButton(buttonRect, text);
            y += rowHeight;

            return isClicked;
        }

        public void addSplit(int height)
        {
            y += height;
        }

        public bool buttonCentered(string text, int fontSize, int window_width)
        {
            int sw = Raylib.MeasureText(text, fontSize);
            int textHeight = (int)Raylib.MeasureTextEx(Raylib.GetFontDefault(), text, fontSize, 0).Y;

            Rectangle buttonRect = new Rectangle(window_width / 2 - sw / 2, y, sw, textHeight);
            bool isClicked = RayGui.GuiButton(buttonRect, text);

            y += textHeight;

            return isClicked;
        }

        public void textCentered(string text, int fontSize, int window_width, Color color)
        {
            int sw = Raylib.MeasureText(text, fontSize);
            int textHeight = (int)Raylib.MeasureTextEx(Raylib.GetFontDefault(), text, fontSize, 0).Y;

            Raylib.DrawText(text, window_width / 2 - sw / 2, y - textHeight, fontSize, color);

            y += textHeight;
        }


        public bool сomboBox(string[] options, ref int selectedIndex, bool isActive)
        {
            Rectangle dropdownRect = new Rectangle(x, y, menuWidth, rowHeight);
            int newSelectedIndex = RayGui.GuiComboBox(dropdownRect, string.Join("\n", options), selectedIndex);

            y += rowHeight;

            if (newSelectedIndex != selectedIndex)
            {
                selectedIndex = newSelectedIndex;
                return true;
            }

            
            return false;
        }


    }
}
